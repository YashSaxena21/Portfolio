Place your profile photo here as 'profile.png'
